# Uber Tax Tracker – Australia (starter MVP)

## What is included
- Local-first PWA for iPhone Safari.
- Income and expense records stored in IndexedDB on the device.
- Expense categories, gross amount, GST treatment, GST amount and business-use percentage.
- Receipt photo attachment (stored locally with the record).
- Financial-year and quarterly summaries.
- CSV export and JSON backup/restore.
- Offline cache after first successful load/install.

## Install on iPhone
1. Publish the contents of this folder to a free HTTPS static host (for example, a GitHub Pages repository).
2. Open the published HTTPS address in Safari on the iPhone.
3. Tap Share → Add to Home Screen → Add.
4. Open it from the new Home Screen icon.
5. Add a test record and export a backup before relying on it.

## Important limitations in this first version
- Receipt images are attached but OCR/automatic extraction is not implemented yet.
- This app does not connect to Uber, bank accounts, the ATO or lodge BAS/tax returns.
- Income records should be entered using gross passenger fares, with platform commission/fees recorded separately where appropriate. Do not treat the net bank payout as gross fares.
- GST estimates assume standard 10% GST where marked “Includes GST”. Some expenses may be GST-free, have no GST, or require a different treatment.
- The “potential GST credit” is only a rough calculation from entered GST × business-use percentage. Eligibility, tax invoices, apportionment and special rules must be checked.
- Income tax deductions are not calculated yet. Motor vehicle deductions require careful treatment; do not add both actual vehicle costs and cents-per-kilometre deductions for the same vehicle use.
- Local browser data can be lost if Safari website data is cleared, the device is lost, or the app is removed. Export JSON backups regularly and store them somewhere safe. Receipt photos are included in the JSON backup.
- The app is a personal record-keeping aid, not ATO-approved tax software or tax advice.

## Development
No build step or third-party JavaScript dependency is required. Serve over HTTPS for PWA installation and service-worker offline caching.
